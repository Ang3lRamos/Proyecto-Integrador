package Login;

import javax.swing.*;
import java.awt.*;

public class Login {
    public JPanel panel1;
    private JTextField lblUsuario;
    private JPasswordField lblContraseña;
    private JButton iniciarSesionButton;
    private JButton registraseButton;
    private JButton olvidasteTuContraseñaButton;
    private JFrame frame;
}
