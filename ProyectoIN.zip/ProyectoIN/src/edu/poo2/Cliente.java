package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cliente {
    public JPanel Pcliente;
    private JLabel clt;
    private JLabel lousr;
    private JLabel correo;
    private JLabel Contraseña;
    private JTextField textcorreo;
    private JTextField textcontraseña;
    private JButton iniciar;
    private JButton crearc;


    public Cliente() {
        iniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame4 = new JFrame("Login");
                frame4.setSize(800,500);
                frame4.setContentPane(new InisiarSesion().inssn);
                frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame4.setVisible(true);

            }
        });
        crearc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame5 = new JFrame("Login");
                frame5.setSize(600,500);
                frame5.setContentPane(new CrearCuenta().Crearc);
                frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame5.setVisible(true);

            }
        });
    }
}
