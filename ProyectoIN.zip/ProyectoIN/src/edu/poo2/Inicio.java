package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inicio {
    public JPanel Seleción;
    private JLabel Logo;
    private JButton cliente;
    private JButton Administrativo;


    public Inicio() {
        cliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame2 = new JFrame("Login");
                frame2.setSize(800,800);
                frame2.setContentPane(new Cliente().Pcliente);
                frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame2.setVisible(true);
            }
        });

        Administrativo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame3 = new JFrame("Login");
                frame3.setSize(800,800);
                frame3.setContentPane(new Adninistrador().admon);
                frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame3.setVisible(true);

            }
        });
    }
}
