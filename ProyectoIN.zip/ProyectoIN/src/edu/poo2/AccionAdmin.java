package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class AccionAdmin {
    private JButton verProductosButton;
    private JButton verProveedoresButton;
    public JPanel pnlAdmin;
    private JButton editarInventarioButton;
    private JButton editarProveedoresButton;
    private JButton inicioButton;


    public AccionAdmin() {
        verProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Productos.pdf";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        verProveedoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Proveedores.pdf";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        inicioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
        editarInventarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Productos.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        editarProveedoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url = "C:\\Users\\angel\\ProyectoIN\\src\\Proveedores.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe", "/C", url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        }
}

