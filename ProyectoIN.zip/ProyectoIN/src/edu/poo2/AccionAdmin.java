package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccionAdmin {
    private JButton verProductosButton;
    private JButton verProveedoresButton;
    public JPanel pnlAdmin;

}
