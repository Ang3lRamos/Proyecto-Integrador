package edu.poo2;

import javax.swing.*;

public class Adninistrador {
    private JLabel administrador;
    private JLabel loadm;
    private JLabel usuario;
    private JLabel contraseña;
    private JTextField textusuario;
    private JTextField textField2;
    private JButton entrar;
    public JPanel admon;
}
