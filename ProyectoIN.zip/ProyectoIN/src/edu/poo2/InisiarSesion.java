package edu.poo2;

import javax.swing.*;

public class InisiarSesion {
    public JPanel inssn;
    private JButton gestionDeQuejasButton;
    private JButton buttonpalinea;
    private JButton Comprar;
}
