package edu.poo2;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Minimercado {
    public JPanel mercadoP;
    private JLabel producto;
    private JTextField textproducto;
    private JLabel valor;
    private JTextField textValorU;
    private JLabel cantidad;
    private JTextField textCantidad;
    private JButton btnGuardar;
    private JTable table1;
    private JButton abrir;
    private JTextField textTotalCompra;
    private JLabel txtTotal;
    private JTextField textImpuesto;
    private JTextField textSubTotal;
    private JLabel txtImpuesto;
    private JLabel txtSubTotal;
    private JButton enviarFacturaButton;
    private JButton limpiarButton;

    private File file;

    public Object total(){
        double valoru = Double.parseDouble(textValorU.getText());
        double cantiada = Double.parseDouble(textCantidad.getText());
        double total = (valoru * cantiada);
        return total;

    }

    private void compraTotal(){
        float suma = 0;
        for(int i= 0;i < table1.getRowCount();i++){
            float renglon;
            renglon = Float.parseFloat(table1.getValueAt(i,3).toString());
            suma += renglon;
        }
        textSubTotal.setText(String.valueOf(suma));
        textImpuesto.setText(String.valueOf(suma*0.19));
        textTotalCompra.setText(String.valueOf(suma*1.19));
    }
    private void guardarTxt(){
        try{
            FileWriter fw = new FileWriter("C:\\Users\\angel\\ProyectoIN\\src\\Factura.txt",true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print("Producto: "+textproducto.getText()+"-");
            pw.print(" Precio: " + textValorU.getText()+"-");
            pw.print(" Unidades: " + textCantidad.getText()+"\n");
            pw.print("=======================\n");
            pw.print("Valor compra: " + textSubTotal.getText()+"\n");
            pw.print("Impuesto: "+textImpuesto.getText()+"\n");
            pw.print("Total a Pagar: " + textTotalCompra.getText()+"\n");
            pw.print("======================\n");
            pw.print("\n");
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void limpiar(){
        textproducto.setText("");
        textValorU.setText("");
        textCantidad.setText("");
    }

    private List<Minimercado> minimercados = new ArrayList<Minimercado>();

    public Minimercado() {
        String[] cols = {"Producto", "Valor unitario", "Cantidad a comprar", "Total"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        table1.setModel(model);

        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                Object[] data = {textproducto.getText() , textValorU.getText(), textCantidad.getText() , total(),textSubTotal.getText(),textImpuesto.getText(),textTotalCompra.getText()};
                model.addRow(data);}catch (Exception ex){
                    System.out.println("Error");
                }
                compraTotal();
                guardarTxt();
                limpiar();
            }
        });
        abrir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Factura.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        enviarFacturaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new FinalCompra().pnlCompra);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    }
}
