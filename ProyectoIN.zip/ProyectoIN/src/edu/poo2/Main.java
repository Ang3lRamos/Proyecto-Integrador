package edu.poo2;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Login" );
        frame.setSize(800,800);
        frame.setContentPane(new Inicio().Seleción);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
