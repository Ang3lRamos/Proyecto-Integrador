package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class FinalCompra {
    private JLabel txtVit;
    private JButton verFacturaButton;
    private JButton pagaEnCasaButton;
    private JButton pagoEnLineaButton;
    private JButton finalizarButton;
    public JPanel pnlCompra;

    public FinalCompra() {
        verFacturaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Factura.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        pagaEnCasaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new DatosDomicilio().pnlDomicilios);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
        pagoEnLineaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="chrome/https://www.aportesenlinea.com/Home/home.aspx?ReturnUrl=%2f";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","chrome",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        finalizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    }
}
