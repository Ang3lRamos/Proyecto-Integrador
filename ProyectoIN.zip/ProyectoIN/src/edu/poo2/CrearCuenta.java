package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrearCuenta {
    public JPanel Crearc;
    private JLabel cree;
    private JLabel nombre;
    private JLabel apellido;
    private JLabel correoE;
    private JLabel contraseña;
    private JLabel vcontraseña;
    private JTextField textnombreC;
    private JTextField textapellidoC;
    private JTextField textUsuario;
    private JButton CrearC;
    private JButton button1;
    private JPasswordField pswContra;
    private JPasswordField pswConContra;

    public CrearCuenta() {

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
        CrearC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = textUsuario.getText();
                String contraseña = pswContra.getText();
                String confirmarContraseña = pswConContra.getText();
                Usuario obj = new Usuario();
                if(Usuario.verificarUsuario(usuario)==-1){
                    obj.setNick(usuario);
                    obj.setcContraseña(contraseña);
                    obj.setcContraseña(confirmarContraseña);
                    ListaUsuario.agregar(obj);
                    JOptionPane.showMessageDialog(null,"Usuario registrado.");
                }else{
                    JOptionPane.showMessageDialog(null,"Este usuario ya esta siendo usado.");
                }
            }
        });
    }
}
