package edu.poo2;

import javax.swing.*;

public class CrearCuenta {
    public JPanel Crearc;
    private JLabel cree;
    private JLabel nombre;
    private JLabel apellido;
    private JLabel correoE;
    private JLabel contraseña;
    private JLabel vcontraseña;
    private JTextField textnombreC;
    private JTextField textapellidoC;
    private JTextField textemail;
    private JTextField textcontraseña;
    private JTextField textconfirmarC;
    private JButton CrearC;
}
