package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrearCuenta {
    public JPanel Crearc;
    private JLabel cree;
    private JLabel nombre;
    private JLabel apellido;
    private JLabel correoE;
    private JLabel contraseña;
    private JLabel vcontraseña;
    private JTextField textnombreC;
    private JTextField textapellidoC;
    private JTextField textemail;
    private JButton CrearC;
    private JButton button1;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;

    public CrearCuenta() {
        CrearC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(new JFrame(),"Cuenta creada");
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    }
}
