package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Adninistrador {
    private JLabel administrador;
    private JLabel loadm;
    private JLabel usuario;
    private JLabel contraseña;
    private JTextField textusuario;
    private JButton entrar;
    public JPanel admon;
    private JPasswordField pswContraAdmin;
    private JButton inicioButton;

    public Adninistrador() {
        inicioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
        entrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = textusuario.getText();
                String password = pswContraAdmin.getText();
                if(usuario.isEmpty() || password.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Verifique los datos.");
                }else{
                    if(usuario.equals("cacastillo1121@gmail.com") && password.equals("1121")){
                        JOptionPane.showMessageDialog(null,"Bienvenido.");
                        JFrame frame = new JFrame("Login" );
                        frame.setSize(800,800);
                        frame.setContentPane(new AccionAdmin().pnlAdmin);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.setVisible(true);
                    }
                    else if(usuario.equals("yuneidy.salgados@unac.edu.co") && password.equals("1231")){
                        JOptionPane.showMessageDialog(null,"Bienvenido.");
                        JFrame frame = new JFrame("Login" );
                        frame.setSize(800,800);
                        frame.setContentPane(new AccionAdmin().pnlAdmin);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.setVisible(true);
                    }
                    else if(usuario.equals("jeanc.blancor@unac.edu.co") && password.equals("2112")){
                        JOptionPane.showMessageDialog(null,"Bienvenido.");
                        JFrame frame = new JFrame("Login" );
                        frame.setSize(800,800);
                        frame.setContentPane(new AccionAdmin().pnlAdmin);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.setVisible(true);
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"Verifique su usuario  contraseña");
                    }
                }
            }
        });
    }
}
