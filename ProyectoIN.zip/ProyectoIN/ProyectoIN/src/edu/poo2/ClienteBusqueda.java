package edu.poo2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Scanner;

public class ClienteBusqueda {
    private JTable tblCompra;
    private JButton btnBuscar;
    private JTextField textBuscar;
    private JButton verInventarioButton;
    public JPanel pnlBusqueda;

    private TableRowSorter trsFiltro;
    String Filtro;

    public void filtro(){
        Filtro = textBuscar.getText();
        trsFiltro.setRowFilter(RowFilter.regexFilter(textBuscar.getText(),0));
    }

    public ClienteBusqueda() {
        String[] cols = {"Producto", "Gramos", "Precio"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        tblCompra.setModel(model);

        verInventarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Producto, Gramos, Precio;
                String archivo = "C:\\Users\\angel\\ProyectoIN\\ProyectoIN\\src\\Productos.txt";
                Scanner linea = null;
                File abrirTxt = new File(archivo);
                try {
                    linea = new Scanner(abrirTxt);
                    while (linea.hasNextLine()) {
                        Producto = linea.nextLine();
                        Gramos = linea.nextLine();
                        Precio = linea.nextLine();
                        model.addRow(new Object[]{Producto, Gramos, Precio});
                    }
                } catch (Exception ez) {
                    JOptionPane.showMessageDialog(null, "Error");
                }
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textBuscar.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        String cadena = textBuscar.getText();
                        textBuscar.setText(cadena);
                        filtro();
                    }
                });
            }
        });
        textBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                trsFiltro = new TableRowSorter(tblCompra.getModel());
                tblCompra.setRowSorter(trsFiltro);
            }
        });
    }
}
