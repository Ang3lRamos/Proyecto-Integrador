package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Vendedor {
    public JPanel Vend;
    private JButton verPedidoButton;
    private JButton hacerFacturaButton;
    private JButton enviarFacturaButton;

    public Vendedor() {
        verPedidoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url ="C:\\Users\\angel\\ProyectoIN\\src\\Pedido.txt";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe","/C",url);
                try {
                    p.start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        hacerFacturaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Minimercado().mercadoP);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    }
}
