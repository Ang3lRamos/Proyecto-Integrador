package edu.poo2;

import jdk.nashorn.internal.scripts.JO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DatosDomicilio {
    private JTextField textDireccion;
    private JTextField textTelefono;
    private JTextField textDAdicionales;
    private JLabel txtDDomicilios;
    private JButton listoButton;
    public JPanel pnlDomicilios;

    public DatosDomicilio() {
        listoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Su pedidio llegara pronto,gracias por su compra :).");
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    }
}
