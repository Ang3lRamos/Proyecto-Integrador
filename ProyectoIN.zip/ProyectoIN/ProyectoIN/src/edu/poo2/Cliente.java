package edu.poo2;

import jdk.nashorn.internal.scripts.JO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cliente {
    public JPanel Pcliente;
    private JLabel clt;
    private JLabel lousr;
    private JLabel correo;
    private JLabel Contraseña;
    private JTextField textcorreo;
    private JButton iniciar;
    private JButton crearc;
    private JPasswordField pswContraseña;
    private JButton volverButton;


    public Cliente() {
        crearc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame5 = new JFrame("Login");
                frame5.setSize(800,800);
                frame5.setContentPane(new CrearCuenta().Crearc);
                frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame5.setVisible(true);
            }
        });
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Login" );
                frame.setSize(800,800);
                frame.setContentPane(new Inicio().Seleción);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
        iniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = textcorreo.getText();
                String contraseña = pswContraseña.getText();
                int pos = Usuario.verificarLogin(usuario,contraseña);
                if(pos == -1){
                    JOptionPane.showMessageDialog(null,"Error verifique los datos.");
                }else{
                    JOptionPane.showMessageDialog(null,"Datos correctos :).");
                    JFrame framePrin = new JFrame("Login" );
                    framePrin.setSize(800,800);
                    framePrin.setContentPane(new CompraCliente().Cc);
                    framePrin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    framePrin.setVisible(true);
                }
            }
        });
    }
}
