package edu.poo2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class AccionAdmin {
    private JButton verProductosButton;
    private JButton verProveedoresButton;
    public JPanel pnlAdmin;
    private JButton editarInventarioButton;
    private JButton editarProveedoresButton;
    private JButton inicioButton;


    public AccionAdmin() {
        verProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame framePrin = new JFrame("Login" );
                framePrin.setSize(800,800);
                framePrin.setContentPane(new RegistroProducto().pnlRegistroP);
                framePrin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                framePrin.setVisible(true);
            }
        });
    }
}

